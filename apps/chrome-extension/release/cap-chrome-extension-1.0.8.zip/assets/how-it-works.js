import"./modulepreload-polyfill.js";import{m as o}from"./page-nav.js";import"./api.js";import"./storage.js";o("how-it-works");
